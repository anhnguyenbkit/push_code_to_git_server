import sys
import threading
import time
import webbrowser
from PyQt5.QtWidgets import QWidget, QLabel, QHBoxLayout, QApplication
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QCursor, QFont

url = "https://www.rokbot.click/blogs/cap-nhat-phien-ban-dao-gem-ro-k"

class BottomFrame(QWidget):

    def __init__(self, parent):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        layout = QHBoxLayout(self)
        
        label = QLabel("Welcome to use Rise of Kingdoms Bot, see update on")
        label.setFont(QFont('Arial', 10))
        
        link = QLabel('<a href="{}"  style="color: white;">rokbot.click</a>'.format(url))
        link.setOpenExternalLinks(True)
        link.setFont(QFont('Arial', 10))
        link.setStyleSheet("color: white;")
        link.setCursor(QCursor(Qt.PointingHandCursor))

        layout.setSpacing(0)  # Remove space between labels
        layout.setContentsMargins(0, 0, 0, 0)  # Set margins to zero
        layout.addWidget(label)
        layout.addWidget(link)
        
        self.setLayout(layout)

        threading.Thread(target=self.callback, daemon=True).start()

    def callback(self):
        time.sleep(2)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    bottomFrame = BottomFrame(None, 800, 600)
    bottomFrame.show()
    sys.exit(app.exec_())
