import os
from pathlib import Path
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QTextEdit, QPushButton, QProgressBar
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from gui.creator import load_bot_config, write_bot_config
from bot_related.bot import Bot
from tasks.constants import BuildingNames
from utils import resource_path
from filepath.file_relative_paths import FilePaths


class SelectedDeviceFrame(QWidget):

    def __init__(self, log_frame, bot):
        super().__init__()
        self.log_frame = log_frame
        self.bot = bot
        self.bot.text_update_signal.connect(self.update_log_frame)
        self.bot_name = bot.bot_name
        self.window_name = bot.bot_window_name
        self.bot_exe_path = bot.exe_path
        self.bot_config = bot.config
        self.bot_id = bot.bot_id
        Path(resource_path(FilePaths.SAVE_FOLDER_PATH.value)).mkdir(parents=True, exist_ok=True)
        Path(resource_path(FilePaths.DATA_PATH.value)).mkdir(parents=True, exist_ok=True)

    def start(self):
        self.bot.config = self.bot_config
        self.bot.config.vipKey = self.bot.vip_current_key
        self.bot.text_update_event = self.on_task_update
        self.bot.config_update_event = lambda **kw: write_bot_config(kw['config'], kw['prefix'])
        self.bot.start(self.bot.do_task)

    def stop(self):
        self.bot.stop()

    def on_task_update(self, text):
        # title, text_list = text['title'], text['text_list']
        # for t in text_list:
        # self.log_frame.append_log(text)
        pass

    def update_log_frame(self, text):
        if self.log_frame:
            self.log_frame.append_log(text)

