from utils import resource_path
from bot_related.bot_config import BotConfig
from filepath.file_relative_paths import FilePaths
import traceback
import json
from bs4 import BeautifulSoup
import os
from config import global_config
import string
from pathlib import Path
import emulator
from utils import resource_path
from adbutils import adb
import psutil

def load_bot_config(prefix, key=''):
    try:
        Path(resource_path(FilePaths.TEST_SRC_FOLDER_PATH.value)).mkdir(parents=True, exist_ok=True)
        Path(resource_path(FilePaths.SAVE_FOLDER_PATH.value)).mkdir(parents=True, exist_ok=True)
        if os.path.exists(
                resource_path(
                    FilePaths.SAVE_FOLDER_PATH.value +
                    '\\{}_config.json'.format(prefix))):
            with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + '\\{}_config.json'.format(prefix))) as f:
                config_dict = json.load(f)
                config = BotConfig(key, config_dict)
                return config
    except Exception:
        traceback.print_exc()
    config = BotConfig(key)
    return config


def write_bot_config(config, prefix):
    config_json = json.dumps(config.__dict__)
    Path(resource_path(FilePaths.SAVE_FOLDER_PATH.value)).mkdir(parents=True, exist_ok=True)
    with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/{}_config.json".format(prefix)), 'w') as f:
        f.write(config_json)


def load_building_pos(prefix):
    try:
        with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/{}_building_pos.json".format(prefix)
                                )) as f:
            building_pos = json.load(f)
    except Exception:
        traceback.print_exc()
        building_pos = None
    return building_pos


def write_building_pos(building_pos, prefix):
    building_pos_json = json.dumps(building_pos)
    with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/{}_building_pos.json".format(prefix)), 'w') as f:
        f.write(building_pos_json)


def remove_all_config():
    try:
        if os.path.exists(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/devices_config.json")):
            os.remove(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/devices_config.json"))
    except Exception:
        traceback.print_exc()


def load_device_config():
    try:
        with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + '/devices_config.json')) as f:
            config = json.load(f)
    except Exception:
        config = []
    return config


def write_device_config(config):
    global_config.logger.info(config)
    config_json = json.dumps(config)
    Path(resource_path(FilePaths.SAVE_FOLDER_PATH.value)).mkdir(parents=True, exist_ok=True)
    with open(resource_path(FilePaths.SAVE_FOLDER_PATH.value + "/devices_config.json"), 'w') as f:
        f.write(config_json)


def get_memu_device():
    devices = []
    exe_file = ""
    try:
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                exe_path = "{0}:\\{1}\\Microvirt\\MEmu\\memuc.exe".format(i, program_name)
                if os.path.exists(exe_path):
                    global_config.logger.debug("found f_name: {exe_path}")
                    exe_file = exe_path
                    break
        f_path = ""
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                f_path = "{0}:\\{1}\\Microvirt\\MEmu\\MemuHyperv VMs\\".format(i, program_name)
                global_config.logger.debug(f"f_name: {f_path}")
                if os.path.exists(f_path):
                    global_config.logger.debug(f"found f_name: {f_path}")
                    memu_instances = os.listdir(f_path)
                    for memu_instance in memu_instances:
                        global_config.logger.debug(f"memu_instance: {memu_instance}")
                        device = {"name": memu_instance, "exe_path": exe_file}
                        devices.append(device)
                    break
    except Exception:
        traceback.print_exc()

    return devices


def get_mumu_device():
    devices = []
    exe_file = ""
    try:
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                exe_path = "{0}:\\{1}\\MuMu\\emulator\\nemu\\EmulatorShell\\NemuPlayer.exe".format(i, program_name)
                if os.path.exists(exe_path):
                    global_config.logger.debug("found f_name: {exe_path}")
                    exe_file = exe_path
                    break
        f_path = ""
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                f_path = "{0}:\\{1}\\MuMu\\emulator\\nemu\\vms\\".format(i, program_name)
                global_config.logger.debug(f"f_name: {f_path}")
                if os.path.exists(f_path):
                    global_config.logger.debug(f"found f_name: {f_path}")
                    memu_instances = os.listdir(f_path)
                    for memu_instance in memu_instances:
                        global_config.logger.debug(f"memu_instance: {memu_instance}")
                        device = {"name": memu_instance, "exe_path": exe_file}
                        devices.append(device)
                    break
    except Exception:
        traceback.print_exc()

    return devices


def get_bluestack_path(filename):
    f_path = ""
    for i in string.ascii_uppercase[:14]:
        for prefix in ['ProgramData', '']:
            f_path = "{}:\\{}\\{}".format(i, prefix, filename)
            global_config.logger.debug(f"f_name: {f_path}")
            if os.path.exists(f_path):
                global_config.logger.debug(f"found f_name: {f_path}")
                return f_path


def get_blue_device():
    devices = []
    try:
        f_path = get_bluestack_path('BlueStacks_nxt\\Engine\\Manager\\BstkGlobal.xml')
        exe_file = ""
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                exe_path = "{0}:\\{1}\\BlueStacks_nxt\\HD-Player.exe".format(i, program_name)
                if os.path.exists(exe_path):
                    exe_file = exe_path
                    global_config.logger.debug(f"found f_name: {exe_path}")
                    break
        if not os.path.exists(f_path):
            # global_config.logger.debug(f'exe_path not exit: {f_path}')
            return []
        with open(f_path, 'r') as f:
            data = f.read()
            Bs_data = BeautifulSoup(data, "xml")
            VirtualBox = Bs_data.find('VirtualBox')
            MachineRegistry = VirtualBox.find('MachineRegistry')
            for item in MachineRegistry.findChildren("MachineEntry", recursive=False):
                global_config.logger.debug(f"item: {item}")
                global_config.logger.debug(f"item: {item.get('src')}")
                device_path = item.get('src')
                global_config.logger.debug(f"device_path: {device_path}")
                device_name = device_path.split('\\')[-1]
                name = device_name[0:len(device_name)-len('.bstk')]
                device = {"name": name, "exe_path": exe_file}
                global_config.logger.debug(f"device: {device}")
                devices.append(device)
    except Exception:
        traceback.print_exc()
    return devices


def get_memu_device_host(memu_name, exe_path):
    memu_path = os.path.dirname(exe_path)
    memu_path = os.path.normpath(memu_path)
    f_path = memu_path + "\\MemuHyperv VMs\\" + memu_name + "\\" + memu_name + ".memu"
    if not os.path.exists(f_path):
        # global_config.logger.debug(f'exe_path not exit: {f_path}')
        return None, None, None
    with open(f_path, 'r') as f:
        data = f.read()
        Bs_data = BeautifulSoup(data, "xml")
        b_memu1 = Bs_data.find('Machine', {'name':memu_name})
        # global_config.logger.debug(f'b_machine: {b_memu1}')
        b_hardware = b_memu1.find('Hardware')
        # global_config.logger.debug(f'b_hardware: {b_hardware}')
        b_network = b_hardware.find('Network')
        guest_data = b_hardware.find('GuestProperties')
        # global_config.logger.debug(f'b_network: {b_network}')
        # global_config.logger.debug(f'guest_data: {guest_data}')
        b_adapter = b_network.find('Adapter')
        b_nat = b_adapter.find('NAT')
        # global_config.logger.debug(f'b_nat: {b_nat}')
        b_name = b_nat.find('Forwarding', {'name':'ADB'})
        name_tag = guest_data.find('GuestProperty', {'name':'name_tag'})
        if name_tag:
            value_name_tag = name_tag.get('value')
        else:
            value_name_tag = memu_name
        host = b_name.get('hostip')
        port = b_name.get('hostport')
        # global_config.logger.debug(f'device: {host}:{port}')
        return host, port, value_name_tag


def get_mumu_device_host(nemu_name, exe_path):
    memu_path = os.path.dirname(exe_path)
    memu_path = os.path.normpath(memu_path)
    f_path = memu_path + "\\..\\vms\\" + nemu_name + "\\" + nemu_name + ".nemu"
    if not os.path.exists(f_path):
        global_config.logger.debug(f'exe_path not exit: {f_path}')
        return None, None
    with open(f_path, 'r') as f:
        data = f.read()
        Bs_data = BeautifulSoup(data, "xml")
        b_nemu1 = Bs_data.find('Machine', {'name':nemu_name})
        # global_config.logger.debug(f'b_machine: {b_memu1}')
        b_hardware = b_nemu1.find('Hardware')
        # global_config.logger.debug(f'b_hardware: {b_hardware}')
        b_network = b_hardware.find('Network')
        # global_config.logger.debug(f'b_network: {b_network}')
        # global_config.logger.debug(f'guest_data: {guest_data}')
        b_adapter = b_network.find('Adapter')
        b_nat = b_adapter.find('NAT')
        # global_config.logger.debug(f'b_nat: {b_nat}')
        b_name = b_nat.find('Forwarding', {'name':'ADB_PORT'})
        host = b_name.get('hostip')
        port = b_name.get('hostport')
        # global_config.logger.debug(f'device: {host}:{port}')
        return host, port


def find_process_path(process_name):
    # Iterate over all running processes
    for proc in psutil.process_iter(['pid', 'name', 'exe']):
        try:
            # Check if process name matches
            if proc.info['name'] == process_name:
                return proc.info['exe']  # Return the executable path
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
    return None


def get_bluestack_device_host(name, exe_path):
    # f_path = "C:\\ProgramData\\BlueStacks_nxt\\bluestacks.conf"
    f_path = get_bluestack_path('BlueStacks_nxt\\bluestacks.conf')
    # blue_path = find_process_path('HD-Player.exe')
    # if not blue_path:
    #     global_config.logger.debug(f"Process HD-Player.exe is not running.")
    #     return
    # else:
    #     global_config.logger.debug(f"Found: {blue_path}")
    # top_path = os.path.dirname(blue_path)
    # global_config.logger.debug(f"top path: {top_path}")
    # f_path = f'{top_path}/bluestacks.conf'
    name_str = None
    host = None
    port = None
    try:
        with open(f_path, 'r') as f:
            lines = f.readlines()
            # global_config.logger.debug(name)
            for line in lines:
                # global_config.logger.debug(line)
                port_search_str = name + ".status.adb_port"
                if port_search_str in line:
                    # global_config.logger.debug(line)
                    port = line.split("=")[1]
                    port = port.replace("\"", "")
                    port = port.rstrip()
                name_search_str = name + ".display_name"
                if name_search_str in line:
                    name_str = line.split("=")[1]
                    name_str = name_str.replace("\"", "")
                    name_str = name_str.rstrip()
    except Exception:
        traceback.print_exc()
    host = "127.0.0.1"

    return name_str, host, port


def get_active_device_names():
    device_active_names = []
    memu_devices = get_memu_device()
    blue_devices = get_blue_device()
    mumu_devices = get_mumu_device()
    for device in memu_devices:
        global_config.logger.debug(device['name'])
        host, port, _ = get_memu_device_host(device['name'], device['exe_path'])
        if not host or not port:
            continue
        device_active_names.append(device['name'])
    for device in blue_devices:
        global_config.logger.debug(device['name'])
        host, port, _ = get_bluestack_device_host(device['name'], device['exe_path'])
        if not host or not port:
            continue
        device_active_names.append(device['name'])
    for device in mumu_devices:
        global_config.logger.debug(device['name'])
        host, port = get_mumu_device_host(device['name'], device['exe_path'])
        if not host or not port:
            continue
        device_active_names.append(device['name'])

    return device_active_names


def get_ld():
    f_path = ""
    for i in string.ascii_uppercase[:14]:
        for j in ['LDPlayer4.0', 'LDPlayer9']:
            f_path = "{}:\\LDPlayer\\{}".format(i, j)
            global_config.logger.debug(f"f_name: {f_path}")
            if os.path.exists(f_path):
                global_config.logger.debug("found f_name: {f_path}")
                break
    try:
        ld = emulator.LDPlayer(ldplayer_dir=f_path)
    except Exception:
        traceback.print_exc()
        return None

    return ld


def get_ld_serial(model):
    for d in adb.device_list():
        global_config.logger.debug(d.prop.model)
        if model == d.prop.model:
            # global_config.logger.info(f"model: {model}, serial: {d.serial}")
            return d.serial
    return ''


def get_ld_config():
    devices = []
    f_paths = []
    #D:\LDPlayer4.0\LDPlayer
    try:
        for i in string.ascii_uppercase[:10]:
            for j in ['LDPlayer4.0', 'LDPlayer9']:
                f_path = "{}:\\LDPlayer\\{}".format(i, j)
                global_config.logger.debug(f"f_name: {f_path}")
                if os.path.exists(f_path):
                    global_config.logger.debug(f"found f_name: {f_path}")
                    f_paths.append(f_path)
                    break
            f_path = "{}:\\LDPlayer4.0\\LDPlayer".format(i)
            global_config.logger.debug(f"f_name: {f_path}")
            if os.path.exists(f_path):
                global_config.logger.debug("found f_name: {f_path}")
                f_paths.append(f_path)
                break
        for i in range(30):
            # D:\LDPlayer\LDPlayer9\vms\config
            for f_path in f_paths:
                lf_file = f"{f_path}\\vms\\config\\leidian{i}.config"
                if not os.path.exists(lf_file):
                    continue
                else:
                    global_config.logger.debug("found lf_file: {}".format(lf_file))
                    device = {}
                    with open(lf_file, "r") as f:
                        lf_config = json.load(f)
                        device['window_name'] = lf_config.get("statusSettings.playerName")\
                            if lf_config.get("statusSettings.playerName") else f"LDPlayer-{i}"
                        device['name'] = "LDPlayer" if i == 0 else f"LDPlayer-{i}"
                        device['exe_path'] = f"{f_path}\\ldconsole.exe"
                        if lf_config.get("propertySettings.phoneModel"):
                            device['model'] = lf_config.get("propertySettings.phoneModel")
                            device['serial'] = get_ld_serial(
                                lf_config.get("propertySettings.phoneModel"))
                        else:
                            device['serial'] = ''
                        devices.append(device)
    except Exception:
        traceback.print_exc()
    return devices


def get_ldplayer(ld):
    if ld:
        return ld.list_name()
    else:
        return []


def get_mumu12_device():
    devices = []
    exe_file = ""
    try:
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                exe_path = "{0}:\\{1}\\Netease\\MuMuPlayerGlobal-12.0\\shell\\MuMuPlayer.exe".format(i, program_name)
                if os.path.exists(exe_path):
                    global_config.logger.debug("found f_name: {exe_path}")
                    exe_file = exe_path
                    break
        f_path = ""
        for i in string.ascii_uppercase[:14]:
            for program_name in ["Program Files", "Program Files (x86)", ""]:
                # E:\Program Files\Netease\MuMuPlayerGlobal-12.0\vms
                f_path = "{0}:\\{1}\\Netease\\MuMuPlayerGlobal-12.0\\vms\\".format(i, program_name)
                global_config.logger.debug(f"f_name: {f_path}")
                if os.path.exists(f_path):
                    global_config.logger.debug(f"found f_name: {f_path}")
                    memu_instances = os.listdir(f_path)
                    for memu_instance in memu_instances:
                        global_config.logger.debug(f"memu_instance: {memu_instance}")
                        device = {"name": memu_instance, "exe_path": exe_file}
                        devices.append(device)
                    break
    except Exception:
        traceback.print_exc()

    return devices


def parse_ip_port(bot_id):
    ip = bot_id
    port = 5555
    if len(bot_id.split(':')) == 2:
        ip = bot_id.split(':')[0]
        port = bot_id.split(':')[1]
    elif len(bot_id.split(':')) == 3:
        ip = bot_id.split(':')[0] + ':' + bot_id.split(':')[1]
        port = bot_id.split(':')[2]

    return ip, port
