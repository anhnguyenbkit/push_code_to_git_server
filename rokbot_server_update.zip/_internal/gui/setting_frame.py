import sys
import webbrowser
from PyQt5.QtWidgets import (
    QWidget, QLabel, QComboBox, QVBoxLayout, QHBoxLayout, QFormLayout,
    QLineEdit, QGroupBox, QCheckBox, QScrollArea, QApplication, QGridLayout
)
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from config import global_config
from config import HAO_I, TWO_CAPTCHA, NONE
from utils import resource_path

class SettingFrame(QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        
        self.container = QWidget()
        self.setWidget(self.container)

        self.container.setStyleSheet("""
            QGroupBox, QLabel, QCheckBox {
                background-color: #3E3E3E;
                color: #FFFFFF;
                border: none;
                border-radius: 5px;
            }
        """)
        layout = QVBoxLayout(self.container)
        layout.setAlignment(Qt.AlignTop)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        layout.addWidget(self.max_try_request())
        layout.addWidget(self.refresh_emulator_time())
        layout.addWidget(self.store_deposit())
        # layout.addWidget(self.twocaptcha_entries())
        layout.addWidget(self.support_frame())

        self.container.setLayout(layout)

    def option_frame(self):
        f = QGroupBox("Pass Verification Method")

        method_label = QLabel('Pass Verification Method:')
        options = [NONE, TWO_CAPTCHA, HAO_I]
        combo = QComboBox()
        combo.addItems(options)
        combo.setCurrentText(global_config.method)
        combo.currentTextChanged.connect(self.on_method_change)

        layout = QHBoxLayout()
        layout.addWidget(method_label)
        layout.addWidget(combo)
        f.setLayout(layout)
        
        return f

    def on_method_change(self, value):
        global_config.method = value
        global_config.write_config()

    def guide_frame(self):
        lf = QGroupBox("Guideline")

        guide_labels = [
            "- Setting emulator with display resolution: 1280x720(240 DPI)",
            "- Setting Graphic quality to Low or Medium",
            "- Setting game language to English",
            "- Support run on MEmu, Bluestacks (32 bit)"
        ]

        layout = QVBoxLayout()
        for text in guide_labels:
            label = QLabel(text)
            layout.addWidget(label)
        lf.setLayout(layout)

        return lf

    def support_frame(self):
        f = QGroupBox("Support")

        icons = [
            ("fb24.png", "https://www.facebook.com/profile.php?id=100092854628679"),
            ("zl24.png", "https://zalo.me/g/gxehfd502"),
            ("dc24.png", "https://discord.gg/EFFRYvUT"),
            ("web.png", "http://rokbot.click/")
        ]

        layout = QHBoxLayout()
        for icon, url in icons:
            label = QLabel()
            pixmap = QPixmap(resource_path(f'resource/icon/{icon}'))
            label.setPixmap(pixmap)
            label.setCursor(Qt.PointingHandCursor)
            label.mousePressEvent = lambda event, url=url: webbrowser.open(url)
            layout.addWidget(label)
        f.setLayout(layout)

        return f

    def twocaptcha_entries(self):
        lf = QGroupBox("2captcha Key")

        default_user_key = global_config.twocaptchaKey
        ue = QLineEdit(default_user_key)
        ue.textChanged.connect(lambda value: self.on_text_change('twocaptchaKey', value))

        layout = QFormLayout()
        layout.addRow("2captcha Key:", ue)
        lf.setLayout(layout)

        return lf

    def max_try_request(self):
        f = QGroupBox("Max Try Request to Server")

        label = QLabel('Max try request send to server:')
        combo = QComboBox()
        options = [1, 2, 3, 4, 5, 6]
        combo.addItems([str(option) for option in options])
        combo.setCurrentText(str(global_config.maxTry))
        combo.currentTextChanged.connect(self.on_max_try_change)

        layout = QHBoxLayout()
        layout.addWidget(label)
        layout.addWidget(combo)
        f.setLayout(layout)

        return f

    def on_max_try_change(self, value):
        global_config.maxTry = int(value)
        global_config.write_config()

    def refresh_emulator_time(self):
        f = QGroupBox("Refresh Emulator Time")

        label = QLabel('Refresh emulator after time (min):')
        line_edit = QLineEdit(str(global_config.refreshTime))
        line_edit.textChanged.connect(lambda value: self.on_text_change('refreshTime', value))

        layout = QHBoxLayout()
        layout.addWidget(label)
        layout.addWidget(line_edit)
        f.setLayout(layout)

        return f

    def store_deposit(self):
        f = QGroupBox("Store Deposit")
        labels_and_fields = [
            # ('Max store gem deposit:', 'maxStore'),
            # ('Max deposit per day:', 'maxDeposit'),
            ('Waiting troops (sec):', 'maxWaiting'),
            # ('Check captcha every (sec):', 'checkCaptchaTime'),
            # ('Break mining gem after (min):', 'short_break'),
            # ('Short Break Time (min):', 'short_break_time'),
            # ('KvK Break mining gem after (min):', 'short_break_kvk'),
            # ('KvK Short Break Time (min):', 'short_break_time_kvk'),
            # ('Reconnect after time (sec):', 'reconnect'),
            # ('Distance swipe minimap:', 'distance_mini'),
            ('Threshold to check emulator:', 'threshold'),
            ('Recheck emulator after(mins):', 'recheck'),
            ('Update interval (mins):', 'update_interval'),
            # ('Close game after solving captcha:', 'close_game_after_solve_captcha'),
            ('Plugins path:', 'plugin'),
            ('Scroll number:', 'scroll'),
            ('Scroll range:', 'scroll_range')
        ]

        layout = QGridLayout()
        for i, (label_text, config_key) in enumerate(labels_and_fields):
            label = QLabel(label_text)
            line_edit = QLineEdit(str(getattr(global_config, config_key)))
            if config_key == 'plugin':
                line_edit.setPlaceholderText(r'D:\Downloads\WhaleBots_1012')
            line_edit.textChanged.connect(lambda value, key=config_key: self.on_text_change(key, value))
            layout.addWidget(label, i, 0)
            layout.addWidget(line_edit, i, 1)

        # Add the 'from' and 'to' QLineEdits for the short break fields
        short_break_fields = [
            # ('Short Break From (min):', 'short_break_from'),
            # ('Short Break To (min):', 'short_break_to'),
            # ('Short Break Time From (min):', 'short_break_time_from'),
            # ('Short Break Time To (min):', 'short_break_time_to'),
            # ('KvK Short Break From (min):', 'short_break_kvk_from'),
            # ('KvK Short Break To (min):', 'short_break_kvk_to'),
            # ('KvK Short Break Time From (min):', 'short_break_time_kvk_from'),
            # ('KvK Short Break Time To (min):', 'short_break_time_kvk_to')
        ]

        for i, (label_text, config_key) in enumerate(short_break_fields, len(labels_and_fields)):
            label = QLabel(label_text)
            line_edit = QLineEdit(str(getattr(global_config, config_key)))
            line_edit.textChanged.connect(lambda value, key=config_key: self.on_text_change(key, value))
            layout.addWidget(label, i, 0)
            layout.addWidget(line_edit, i, 1)

        checkboxes = [
            # ('Return to previous deposit', 'returnPre'),
            # ('Auto fix emulator error', 'autofix'),
            ('Enable update config', 'update_config'),
            ('Close emulator when break', 'close_game'),
            # ('Break when full march HK', 'break_when_full_march'),
            # ('Break when full march LK', 'break_when_full_march_LK')
        ]

        for i, (label_text, config_key) in enumerate(checkboxes, len(labels_and_fields) + len(short_break_fields)):
            checkbox = QCheckBox(label_text)
            checkbox.setChecked(getattr(global_config, config_key))
            checkbox.stateChanged.connect(lambda state, key=config_key: self.on_check_change(key, state))
            layout.addWidget(checkbox, i, 0, 1, 2)

        f.setLayout(layout)

        return f

    def on_text_change(self, attr_name, value):
        if attr_name == 'plugin':
            # Plugin path is a string, set it as is
            setattr(global_config, attr_name, value)
        else:
            # For other attributes:
            # If the value is an empty string, set it to '0'
            if value == '':
                value = '0'
            
            # Check if the value is a digit or a float, and set the attribute accordingly
            if value.isdigit() or value.replace('.', '', 1).isdigit():
                setattr(global_config, attr_name, float(value) if '.' in value else int(value))
            else:
                # If not a digit or float, set the value as is
                setattr(global_config, attr_name, value)

        # Write the updated configuration
        global_config.write_config()

    def on_check_change(self, attr_name, state):
        value = state == Qt.Checked
        setattr(global_config, attr_name, value)
        global_config.write_config()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    settings_frame = SettingFrame()
    settings_frame.show()
    sys.exit(app.exec_())
