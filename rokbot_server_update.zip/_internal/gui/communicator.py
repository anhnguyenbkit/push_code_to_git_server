from PyQt5.QtCore import QObject, pyqtSignal

class Communicator(QObject):
    message_signal = pyqtSignal(str, str)
