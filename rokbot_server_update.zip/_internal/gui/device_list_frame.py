import sys
import os
from PyQt5.QtWidgets import QApplication, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QLineEdit, QCheckBox, QTextEdit, QScrollArea, QFrame, QMessageBox
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt
from gui.selected_device_frame import SelectedDeviceFrame
from gui.creator import write_device_config, load_device_config, get_memu_device, get_memu_device_host, get_blue_device, get_bluestack_device_host, get_ld_config, find_process_path, get_mumu_device, get_mumu_device_host, load_bot_config, write_bot_config, get_mumu12_device
import adb
import re
import traceback
import time
import threading
from utils import resource_path
import subprocess
from subprocess import PIPE
import uiautomator2 as u2
from config import global_config
import adbutils
from filepath.file_relative_paths import FilePaths
from gui.log_frame import LogFrame
import atexit

RUNNING = 'running'
DISCONNECTED = 'OFFLINE'
CONNECTED = 'Online'

PATH = FilePaths.DATA_PATH.value


class DeviceListFrame(QWidget):

    def __init__(self, main_frame):
        super().__init__()
        self.devices_config = load_device_config()
        self.main_frame = main_frame

        # Create a QLineEdit for window name input
        self.window_name_input = QLineEdit(self)
        self.window_name_input.setPlaceholderText("Enter window name")

        self.dlt = DeviceListTable(self, main_frame, self.devices_config)
        
        self.layout = QVBoxLayout(self)
        button_layout = QHBoxLayout()
        
        self.button_refresh = QPushButton("Refresh")
        self.button_runall = QPushButton("Run selected")
        self.button_stopall = QPushButton("Stop selected")
        self.button_delall = QPushButton("Delete selected")
        self.button_add = QPushButton("Add Bluestack window")  # Add button
        self.button_add.setFixedHeight(30)

        button_layout.addWidget(self.button_refresh)
        button_layout.addWidget(self.button_runall)
        button_layout.addWidget(self.button_stopall)
        button_layout.addWidget(self.button_delall)

        entry_layout = QHBoxLayout()
        entry_layout.addWidget(self.window_name_input)
        entry_layout.addWidget(self.button_add)

        self.layout.addLayout(button_layout)
        self.layout.addLayout(entry_layout)
        self.layout.addWidget(self.dlt)

        self.button_refresh.clicked.connect(self.update_device_list)
        self.button_runall.clicked.connect(self.dlt.run_all)
        self.button_stopall.clicked.connect(self.dlt.stop_all)
        self.button_delall.clicked.connect(self.dlt.del_all)
        self.button_add.clicked.connect(self.add_bluestack_device)  # Connect the Add button to add_device

        buttons = [self.button_refresh, self.button_runall, self.button_stopall, self.button_delall]
        for button in buttons:
            button.setFixedHeight(30)
            # button.setFixedWidth(120)  # Set fixed width for buttons
            # button_layout.addWidget(button)

        self.add_device()
        self.update_device_list(force_refresh=True)
        atexit.register(self.save_device_config)

    def add_bluestack_device(self):
        # Get the window name from the input field and set the window title
        window_name = self.window_name_input.text()
        global_config.logger.debug(f'window name: {window_name}')
        # Call self.dlt.add_row when Add button is clicked
        exe_path = find_process_path('HD-Player.exe')
        if not exe_path:
            exe_path = 'Blue'
        config = {"windows_name": window_name, 'ip': window_name, 'port': 5555, 'exe_path': exe_path}  # Example config using the window name
        self.dlt.add_row(self.main_frame, config)  # Call the add_row method with main_frame and config
        is_existed_window = False
        for i in range(len(self.devices_config)):
            if self.devices_config[i].get('windows_name') == config['windows_name']:
                self.devices_config[i] = config
                is_existed_window = True
                break
        if not is_existed_window:
            self.devices_config.append(config)

    def get_device_config(self, window_name):
        for device in self.devices_config:
            if device['windows_name'] == window_name:
                return device
        return None

    def update_device_config(self, window_name, host, port, device, model="na"):
        device_json = self.get_device_config(window_name)
        if not device_json:
            device_json = {}
        device_json['bot_name'] = device['name']
        device_json['windows_name'] = window_name
        device_json['exe_path'] = device['exe_path']
        device_json['ip'] = host
        device_json['port'] = port
        device_json['model'] = model
        for i in range(len(self.devices_config)):
            if self.devices_config[i].get('windows_name') == device_json['windows_name']:
                self.devices_config[i] = device_json
                return
        self.devices_config.append(device_json)

    def get_devices_config(self):
        devices = get_memu_device()
        device_bluests = get_blue_device()
        device_lds = get_ld_config()
        device_mumus = get_mumu_device()
        device_mumus_12 = get_mumu12_device()

        for device in devices:
            host, port, window_name = get_memu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(window_name, host, port, device)

        for device in device_bluests:
            window_name, host, port = get_bluestack_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(window_name, host, port, device)

        for device in device_lds:
            if not device['serial']:
                continue
            self.update_device_config(device['window_name'], device['serial'], "6666", device, model=device['model'])

        for device in device_mumus:
            host, port = get_mumu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(device['name'], host, port, device)

        for device in device_mumus_12:
            host, port = get_mumu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(device['name'], host, port, device)

    def add_device(self, force_refresh=False):
        if len(self.devices_config) == 0 or force_refresh:
            self.get_devices_config()

    def update_device_list(self, force_refresh=False):
        if not force_refresh:
            adb.kill_adb_server()
            time.sleep(2)
            adb.unlock_adb_limit()
            adb.enable_adb()
            self.get_devices_config()
            for config in self.devices_config:
                self.dlt.add_row(self.main_frame, config)
        else:
            self.dlt.create_device_list_frame(self.devices_config)

    def save_device_config(self):
        write_device_config(self.devices_config)


class DeviceListTable(QScrollArea):
    def __init__(self, parent, main_frame, configs):
        super().__init__(parent)
        self.parent = parent
        self.main_frame = main_frame
        self.device_rows = []
        self.device_activated = []
        self.configs = configs
        atexit.register(self.exit_handler)
        self.setWidgetResizable(True)

        self.content_widget = QWidget()
        self.setWidget(self.content_widget)

        self.layout = QVBoxLayout(self.content_widget)
        self.layout.setAlignment(Qt.AlignTop)
        self.layout.setSpacing(0)

    def create_device_list_frame(self, configs):
        for config in configs:
            self.add_row(self.main_frame, config)

    def exit_handler(self):
        self.device_activated.clear()

    def run_all(self):
        for row in self.device_rows:
            if row.bot_config.is_enable:
                if row.start_btn.text() == "Start":
                    row.start_btn.setText("Stop")
                    row.start_btn.setStyleSheet("background-color: red;")
                    row.add_log_frame()
                    row.run_device()
                    if row.device_frame:
                        thread = threading.Thread(target=self._start_bot_with_delay, args=(row.device_frame,))
                        thread.daemon = True
                        thread.start()

    def _start_bot_with_delay(self, device_frame):
        time.sleep(2)
        device_frame.start()

    def stop_all(self):
        for row in self.device_rows:
            if row.bot_config.is_enable:
                if row.start_btn.text() == "Stop":
                    row.start_btn.setStyleSheet("background-color: green;")
                    row.device_frame.stop()
                    row.start_btn.setText("Start")

    def del_all(self):
        for row in self.device_rows:
            if row.bot_config.is_enable:
                self.on_delete_click(row)

    def add_row(self, main_frame, config):
        window_name = config.get('windows_name', 'None')
        instance_name = config.get('bot_name', 'None')
        exe_path = config.get('exe_path', 'None')
        ip = config.get('ip', '')
        port = config.get('port', 5555)
        model = config.get('model', '')
        global_config.logger.debug(f'add window name: {window_name}')
        if f'{ip}:{port}' in self.device_activated:
            global_config.logger.debug(f'same ip and port: {ip}:{port}')
            return

        self.device_activated.append(f'{ip}:{port}')
        try:
            new_row = DeviceRow(self.content_widget, main_frame, window_name, instance_name, exe_path, ip, port, model)
            new_row.set_on_display_click(self.on_display_click)
            new_row.set_on_del_click(self.on_delete_click)
            new_row.set_on_start_click(self.on_start_stop_device)
            self.device_rows.append(new_row)
            self.layout.addWidget(new_row)
        except Exception:
            traceback.print_exc()

    def remove_row(self, row):
        try:
            if row.device_frame is not None:
                row.device_frame.stop()
                row.device_frame.deleteLater()
            self.device_rows.remove(row)
            row.deleteLater()
        except Exception:
            traceback.print_exc()

    def on_display_click(self, row):
        # row.device_frame.setVisible(True)
        # pass
        row.add_log_frame()
        row.run_device()

    def on_start_stop_device(self, row):
        row.add_log_frame()
        row.run_device()
        if row.start_btn.text() == "Start":
            if row.device_frame:
                thread = threading.Thread(target=self._start_bot_with_delay, args=(row.device_frame,))
                thread.daemon = True
                thread.start()
            row.start_btn.setText("Stop")
            row.start_btn.setStyleSheet("background-color: red;")
        else:
            row.device_frame.stop()
            row.start_btn.setText("Start")
            row.start_btn.setStyleSheet("background-color: green;")

    def on_delete_click(self, row):
        reply = QMessageBox.question(self, 'Delete Confirmation',
                                     f"Are you sure you want to delete {row.window_name}?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            ip, port = row.ip, row.port
            config_removes = self.get_remove_config(ip, port)
            global_config.logger.debug(f'self.device_activated: {self.device_activated} - {ip}:{port}')
            for item in config_removes:
                self.parent.devices_config.remove(item)
                addr_remove = item.get('ip') + ":" + str(item.get('port'))
                global_config.logger.debug(f'addr: {addr_remove}')
                if addr_remove in self.device_activated:
                    global_config.logger.debug(f'remove: {addr_remove}')
                    self.device_activated.remove(addr_remove)
            write_device_config(self.parent.devices_config)
            self.remove_row(row)

    def get_remove_config(self, ip, port):
        global_config.logger.debug(f'ip: {ip}, port: {port}')
        addrs = []
        for addr in self.parent.devices_config:
            global_config.logger.debug(f'addr: {addr}')
            if addr.get('ip') == ip and addr.get('port') == port:
                addrs.append(addr)
        return addrs


class DeviceRow(QWidget):
    def __init__(self, parent, main_frame, window_name, instance_name, exe_path, ip, port, model):
        super().__init__(parent)
        self.run_device_lock = threading.Lock()
        self.main_frame = main_frame
        self.window_name = window_name
        self.instance_name = instance_name
        self.id = f"{ip}:{port}"
        self.exe_path = exe_path
        self.ip = ip
        self.port = port
        self.model = model
        self.device_frame = None
        self.device_frame_old = None
        self.bot_config = load_bot_config(f"{ip}_{port}")
        self.is_enable = self.bot_config.is_enable

        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(2)
        
        self.is_enable_check_bot = QCheckBox()
        self.is_enable_check_bot.setChecked(self.is_enable)
        self.is_enable_check_bot.stateChanged.connect(self.save_config)
        self.is_enable_check_bot.setStyleSheet("QCheckBox::indicator { width: 20px; height: 20px; }")

        self.icon = QLabel()
        self.set_icon()

        self.name_label = QLabel(self.window_name)
        self.name_label.setFixedWidth(100)  # Set fixed width for key entry
        self.name_label.setFixedHeight(30)
        self.status_label = QLabel(DISCONNECTED)
        self.key_label = QLabel('Key: ')
        self.key_entry = QLineEdit(self.bot_config.vipKey)
        self.key_entry.editingFinished.connect(self.save_key)
        self.key_entry.setFixedWidth(200)  # Set fixed width for key entry
        self.key_entry.setFixedHeight(30)
        self.display_btn = QPushButton('Display')
        self.display_btn.setFixedHeight(30)
        self.del_btn = QPushButton('Delete')
        self.del_btn.setFixedHeight(30)
        self.start_btn = QPushButton('Start')
        self.start_btn.setFixedHeight(30)

        self.layout.addWidget(self.is_enable_check_bot)
        self.layout.addWidget(self.icon)
        self.layout.addWidget(self.name_label)
        self.layout.addWidget(self.key_label)
        self.layout.addWidget(self.key_entry)
        self.layout.addWidget(self.status_label)
        self.layout.addWidget(self.display_btn)
        self.layout.addWidget(self.start_btn)
        self.layout.addWidget(self.del_btn)
        self.log_frame = None

    def set_icon(self):
        if not self.exe_path:
            self.exe_path = ''
        if 'MEmu' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\MEmu.png')))
        elif 'LDPlayer' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\ldplayer.png')))
        elif 'NemuPlayer.exe' in self.exe_path or 'MuMuPlayer.exe' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\mumu.png')))
        else:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\bluestack.png')))

    def save_key(self):
        new_key = self.key_entry.text()
        self.bot_config.vipKey = new_key
        write_bot_config(self.bot_config, f"{self.ip}_{self.port}")

    def save_config(self):
        self.bot_config.is_enable = self.is_enable_check_bot.isChecked()
        write_bot_config(self.bot_config, f"{self.ip}_{self.port}")

    def set_on_start_click(self, on_click):
        self.start_btn.clicked.connect(lambda: on_click(self))

    def set_on_del_click(self, on_click):
        self.del_btn.clicked.connect(lambda: on_click(self))

    def set_on_display_click(self, on_click):
        self.display_btn.clicked.connect(lambda: on_click(self))

    def add_log_frame(self):
        if not self.log_frame:
            self.log_frame = LogFrame()
            self.main_frame.addWidget(self.log_frame)
        self.main_frame.setCurrentWidget(self.log_frame)

    def run_device(self):
        with self.run_device_lock:
            if self.device_frame is None:
                try:
                    if 'LDPlayer' in self.instance_name:
                        self.device = adbutils.adb.device(self.ip)
                    else:
                        self.device = adbutils.adb.device(self.id)
                except Exception:
                    traceback.print_exc()
                self.status_label.setText(CONNECTED if self.device else DISCONNECTED)
                self.bot_config = load_bot_config(f"{self.ip}_{self.port}")
                self.device_frame = SelectedDeviceFrame(self.log_frame, self.window_name, self.instance_name, self.id, self.exe_path, self.main_frame, self.bot_config.vipKey, self.model)
