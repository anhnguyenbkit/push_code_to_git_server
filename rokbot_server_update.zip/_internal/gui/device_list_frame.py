import sys
import os
from PyQt5.QtWidgets import QApplication, QProgressDialog, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QLineEdit, QCheckBox, QTextEdit, QScrollArea, QFrame, QMessageBox
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from gui.selected_device_frame import SelectedDeviceFrame
from gui.creator import write_device_config, load_device_config, get_memu_device, get_memu_device_host, get_blue_device, get_bluestack_device_host, get_ld_config, find_process_path, get_mumu_device, get_mumu_device_host, load_bot_config, write_bot_config, get_mumu12_device
import adb
import re
import traceback
import time
import threading
from utils import resource_path
import subprocess
from subprocess import PIPE
import uiautomator2 as u2
from config import global_config
import adbutils
from filepath.file_relative_paths import FilePaths
from gui.log_frame import LogFrame
import atexit
from control_worker import register_bot, unregister_bot, get_registered_bot_count

RUNNING = 'running'
DISCONNECTED = 'OFFLINE'
CONNECTED = 'Online'

PATH = FilePaths.DATA_PATH.value


class DeviceListFrame(QWidget):

    def __init__(self, main_frame):
        super().__init__()
        self.devices_config = load_device_config()
        self.main_frame = main_frame

        # Create a QLineEdit for window name input
        self.window_name_input = QLineEdit(self)
        self.window_name_input.setPlaceholderText("Enter window name")

        self.dlt = DeviceListTable(self, main_frame, self.devices_config)
        
        self.layout = QVBoxLayout(self)
        button_layout = QHBoxLayout()

        self.total_devices_label = QLabel("Total devices: 0")
        self.total_devices_label.setFixedHeight(30)
        
        self.disk_info_label = QLabel("Disk Info: Loading...")
        self.disk_info_label.setFixedHeight(30)


        self.button_runall = QPushButton("Run selected")
        self.button_stopall = QPushButton("Stop selected")
        self.button_delall = QPushButton("Delete selected")
        self.button_add = QPushButton("Add Bluestack window")  # Add button
        self.button_add.setFixedHeight(30)

        button_layout.addWidget(self.button_runall)
        button_layout.addWidget(self.button_stopall)
        button_layout.addWidget(self.button_delall)
        button_layout.addWidget(self.total_devices_label)
        button_layout.addWidget(self.disk_info_label) # Add disk info label

        entry_layout = QHBoxLayout()
        entry_layout.addWidget(self.window_name_input)
        entry_layout.addWidget(self.button_add)

        self.layout.addLayout(button_layout)
        self.layout.addLayout(entry_layout)
        self.layout.addWidget(self.dlt)

        self.button_runall.clicked.connect(self.dlt.run_all)
        self.button_stopall.clicked.connect(self.dlt.stop_all)
        self.button_delall.clicked.connect(self.dlt.del_all)
        self.button_add.clicked.connect(self.add_bluestack_device)  # Connect the Add button to add_device

        buttons = [self.button_runall, self.button_stopall, self.button_delall]
        for button in buttons:
            button.setFixedHeight(30)
            # button.setFixedWidth(120)  # Set fixed width for buttons
            # button_layout.addWidget(button)
 
        self.add_device()
        self.update_device_list(force_refresh=True)

        self.disk_info_timer = QTimer(self)
        self.disk_info_timer.timeout.connect(self.show_disk_info)
        self.disk_info_timer.start(60000) # Update every 60 seconds (1 minute)
        self.show_disk_info() # Initial call

    def update_total_devices_label(self, count):
        self.total_devices_label.setText(f"Total active: {count} |")

    def add_bluestack_device(self):
        # Get the window name from the input field and set the window title
        window_name = self.window_name_input.text()
        global_config.logger.debug(f'window name: {window_name}')
        # Call self.dlt.add_row when Add button is clicked
        exe_path = find_process_path('HD-Player.exe')
        if not exe_path:
            exe_path = 'Blue'
        config = {"windows_name": window_name, 'ip': window_name, 'port': 5555, 'exe_path': exe_path}  # Example config using the window name
        self.dlt.add_row(self.main_frame, config)  # Call the add_row method with main_frame and config
        is_existed_window = False
        for i in range(len(self.devices_config)):
            if self.devices_config[i].get('windows_name') == config['windows_name']:
                self.devices_config[i] = config
                is_existed_window = True
                break
        if not is_existed_window:
            self.devices_config.append(config)

    def get_device_config(self, window_name):
        for device in self.devices_config:
            if device['windows_name'] == window_name:
                return device
        return None

    def update_device_config(self, window_name, host, port, device, model="na"):
        device_json = self.get_device_config(window_name)
        if not device_json:
            device_json = {}
        device_json['bot_name'] = device['name']
        device_json['windows_name'] = window_name
        device_json['exe_path'] = device['exe_path']
        device_json['ip'] = host
        device_json['port'] = port
        device_json['model'] = model
        for i in range(len(self.devices_config)):
            if self.devices_config[i].get('windows_name') == device_json['windows_name']:
                self.devices_config[i] = device_json
                return
        self.devices_config.append(device_json)

    def get_devices_config(self):
        devices = get_memu_device()
        device_bluests = get_blue_device()
        device_lds = get_ld_config()
        device_mumus = get_mumu_device()
        device_mumus_12 = get_mumu12_device()

        for device in devices:
            host, port, window_name = get_memu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(window_name, host, port, device)

        for device in device_bluests:
            window_name, host, port = get_bluestack_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(window_name, host, port, device)

        for device in device_lds:
            if not device['serial']:
                continue
            self.update_device_config(device['window_name'], device['serial'], "6666", device, model=device['model'])

        for device in device_mumus:
            host, port = get_mumu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(device['name'], host, port, device)

        for device in device_mumus_12:
            host, port = get_mumu_device_host(device['name'], device['exe_path'])
            if not host or not port:
                continue
            self.update_device_config(device['name'], host, port, device)

    def add_device(self, force_refresh=False):
        if len(self.devices_config) == 0 or force_refresh:
            self.get_devices_config()

    def update_device_list(self, force_refresh=False):
        if not force_refresh:
            # adb.kill_adb_server()
            # time.sleep(2)
            # adb.unlock_adb_limit()
            # adb.enable_adb()
            self.get_devices_config()
            for config in self.devices_config:
                self.dlt.add_row(self.main_frame, config)
        else:
            self.dlt.create_device_list_frame(self.devices_config)

    def save_device_config(self):
        write_device_config(self.devices_config)

    def show_disk_info(self):
        try:
            command = "wmic logicaldisk get Caption,Size,FreeSpace"
            process = subprocess.Popen(command, shell=True, stdout=PIPE, stderr=PIPE, text=True)
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                # Parse stdout to format it nicely, e.g., show only C: drive info
                lines = stdout.strip().split('\n')
                disk_info_text = ""
                if len(lines) > 1:
                    headers = lines[0].split()
                    print(f"headers: {headers}")
                    # Find indices for Caption, Size, FreeSpace
                    caption_idx = headers.index("Caption") if "Caption" in headers else -1
                    size_idx = headers.index("Size") if "Size" in headers else -1
                    freespace_idx = headers.index("FreeSpace") if "FreeSpace" in headers else -1

                    for line in lines[1:]:
                        parts = line.split()
                        if len(parts) > max(caption_idx, size_idx, freespace_idx):
                            caption = parts[caption_idx] if caption_idx != -1 else "N/A"
                            size_bytes = int(parts[size_idx]) if size_idx != -1 and parts[size_idx].isdigit() else 0
                            freespace_bytes = int(parts[freespace_idx]) if freespace_idx != -1 and parts[freespace_idx].isdigit() else 0

                            # Convert bytes to GB for readability
                            size_gb = round(size_bytes / (1024**3), 2)
                            freespace_gb = round(freespace_bytes / (1024**3), 2)
                            disk_info_text += f"{caption} {freespace_gb}GB free | "
                    disk_info_text = disk_info_text.rstrip(" | ")

                if not disk_info_text:
                    disk_info_text = "Disk Info: Could not retrieve C: drive information."

                self.disk_info_label.setText(f"Disk Info: {disk_info_text}")
            else:
                self.disk_info_label.setText(f"Disk Info Error: {stderr.strip()}")
        except Exception as e:
            self.disk_info_label.setText(f"Disk Info Error: {e}")


class DeviceRunner(QThread):
    device_ready = pyqtSignal(dict)

    def __init__(self, row):
        super().__init__()
        self.row = row

    def run(self):
        with self.row.run_device_lock:
            if self.row.bot is None:
                from bot_related.bot import Bot
                self.row.bot = Bot(self.row.id, self.row.window_name, self.row.instance_name, self.row.exe_path, self.row.bot_config.vipKey, self.row.model)
            is_connected = self.row.bot.is_device_online()
            self.row.bot.moveToThread(QApplication.instance().thread())
        self.device_ready.emit({
            "row": self.row,
            "bot": self.row.bot,
            "is_connected": is_connected
        })


class BotStarter(QThread):
    def __init__(self, device_frame):
        super().__init__()
        self.device_frame = device_frame

    def run(self):
        time.sleep(2)
        self.device_frame.start()


class Worker(QThread):
    bot_registered = pyqtSignal()
    show_warning_signal = pyqtSignal(str, str, QWidget)

    def __init__(self, row, device_frame):
        super().__init__()
        self.row = row
        self.device_frame = device_frame
        self.is_running = True
        self.threads = []

    def run(self):
        if not self.is_running:
            return
        
        if self.row.bot_config.is_enable:
            if self.device_frame:
                self.bot_starter = BotStarter(self.device_frame)
                self.bot_starter.finished.connect(self.bot_starter.deleteLater)
                self.bot_starter.start()
            register_bot(self.row.bot_config.vipKey, self.row.window_name, self.device_frame.bot)
            self.bot_registered.emit()
        else:
            global_config.logger.debug(f"Bot {self.row.window_name} is not enabled; skipping start.")
            self.show_warning_signal.emit("Bot Not Enabled", f"Bot {self.row.window_name} is not enabled.", self.row)

    def stop(self):
        self.is_running = False


class DeviceListTable(QScrollArea):
    def __init__(self, parent: DeviceListFrame, main_frame, configs):
        super().__init__(parent)
        self.parent = parent
        self.main_frame = main_frame
        self.device_rows = []
        self.device_activated = []
        self.configs = configs
        self.device_count = 0
        self.threads = []
        self.bots_started_count = 0
        atexit.register(self.exit_handler)
        self.setWidgetResizable(True)

        self.content_widget = QWidget()
        self.setWidget(self.content_widget)

        self.layout = QVBoxLayout(self.content_widget)
        self.layout.setAlignment(Qt.AlignTop)
        self.layout.setSpacing(0)

    def create_device_list_frame(self, configs):
        for config in configs:
            self.add_row(self.main_frame, config)

    def exit_handler(self):
        self.device_activated.clear()

    def run_all(self):
        rows_to_run = [row for row in self.device_rows if row.bot_config.is_enable and row.start_btn.text() == "Start"]
        if not rows_to_run:
            return

        global_config.logger.debug(f"Run All: {len(rows_to_run)} bots to run.")
        self.bots_started_count = 0
        self.progress_dialog = QProgressDialog("Loading bots...", "Cancel", 0, len(rows_to_run), self)
        self.progress_dialog.setWindowModality(Qt.WindowModal)
        self.progress_dialog.setAutoClose(True)
        self.progress_dialog.show()

        for row in rows_to_run:
            device_runner = DeviceRunner(row)
            device_runner.device_ready.connect(self.start_worker)
            device_runner.finished.connect(self.on_thread_finished)
            self.threads.append(device_runner)
            device_runner.start()

    def start_worker(self, device_info):
        row = device_info["row"]
        bot = device_info["bot"]
        is_connected = device_info["is_connected"]

        row.status_label.setText(CONNECTED if is_connected else DISCONNECTED)
        row.start_btn.setText("Stop")
        row.start_btn.setStyleSheet("background-color: red;")
        row.status_label.setStyleSheet("color: green;")
        row.add_log_frame()

        if row.device_frame is None:
            row.device_frame = SelectedDeviceFrame(row.log_frame, bot)

        worker = Worker(row, row.device_frame)
        worker.bot_registered.connect(self.update_progress)
        worker.show_warning_signal.connect(self.display_warning)
        worker.finished.connect(self.on_thread_finished)
        self.threads.append(worker)
        if hasattr(self, 'progress_dialog') and self.progress_dialog.isVisible():
            self.progress_dialog.canceled.connect(worker.stop)
        worker.start()

    def update_progress(self):
        if hasattr(self, 'progress_dialog') and self.progress_dialog.isVisible():
            self.bots_started_count += 1
            total = self.progress_dialog.maximum()
            global_config.logger.debug(f"Updating progress: {self.bots_started_count}/{total}")
            self.progress_dialog.setValue(self.bots_started_count)
            QApplication.processEvents()

    def display_warning(self, title, text, parent_widget):
        QMessageBox.warning(parent_widget, title, text)

    def on_thread_finished(self):
        thread = self.sender()
        self.threads.remove(thread)

    def stop_all(self):
        for row in self.device_rows:
            if row.bot_config.is_enable:
                if row.start_btn.text() == "Stop":
                    row.start_btn.setStyleSheet("background-color: green;")
                    row.status_label.setText(DISCONNECTED)
                    row.status_label.setStyleSheet("color: red;")
                    row.device_frame.stop()
                    row.start_btn.setText("Start")
                    unregister_bot(row.bot_config.vipKey)

    def del_all(self):
        for row in self.device_rows:
            if row.bot_config.is_enable:
                self.on_delete_click(row)

    def add_row(self, main_frame, config):
        window_name = config.get('windows_name', 'None')
        instance_name = config.get('bot_name', 'None')
        exe_path = config.get('exe_path', 'None')
        ip = config.get('ip', '')
        port = config.get('port', 5555)
        model = config.get('model', '')
        global_config.logger.debug(f'add window name: {window_name}')
        if f'{ip}:{port}' in self.device_activated:
            global_config.logger.debug(f'same ip and port: {ip}:{port}')
            return

        self.device_activated.append(f'{ip}:{port}')
        self.device_count += 1
        try:
            new_row = DeviceRow(self.content_widget, self, main_frame, window_name, instance_name, exe_path, ip, port, model)
            new_row.set_on_display_click(self.on_display_click)
            new_row.set_on_del_click(self.on_delete_click)
            new_row.set_on_start_click(self.on_start_stop_device)
            self.device_rows.append(new_row)
            self.layout.addWidget(new_row)
            self._update_total_devices_count()
        except Exception:
            traceback.print_exc()

    def remove_row(self, row):
        try:
            if row.device_frame is not None:
                row.device_frame.stop()
                row.device_frame.deleteLater()
            self.device_rows.remove(row)
            row.deleteLater()
        except Exception:
            traceback.print_exc()

    def on_display_click(self, row):
        row.add_log_frame()

    def on_start_stop_device(self, row):
        if row.start_btn.text() == "Start":

            device_runner = DeviceRunner(row)
            device_runner.device_ready.connect(self.start_worker)
            device_runner.finished.connect(self.on_thread_finished)
            self.threads.append(device_runner)
            device_runner.start()
        else:
            row.start_btn.setText("Start")
            row.start_btn.setStyleSheet("background-color: green;")
            row.status_label.setText(DISCONNECTED)
            row.status_label.setStyleSheet("color: red;")
            row.device_frame.stop()
            unregister_bot(row.bot_config.vipKey)

    def on_delete_click(self, row):
        reply = QMessageBox.question(self, 'Delete Confirmation',
                                     f"Are you sure you want to delete {row.window_name}?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            ip, port = row.ip, row.port
            config_removes = self.get_remove_config(ip, port)
            global_config.logger.debug(f'self.device_activated: {self.device_activated} - {ip}:{port}')
            for item in config_removes:
                self.parent.devices_config.remove(item)
                addr_remove = item.get('ip') + ":" + str(item.get('port'))
                global_config.logger.debug(f'addr: {addr_remove}')
                if addr_remove in self.device_activated:
                    global_config.logger.debug(f'remove: {addr_remove}')
                    self.device_activated.remove(addr_remove)
            write_device_config(self.parent.devices_config)
            self.remove_row(row)
            self._update_total_devices_count()

    def get_remove_config(self, ip, port):
        global_config.logger.debug(f'ip: {ip}, port: {port}')
        addrs = []
        for addr in self.parent.devices_config:
            global_config.logger.debug(f'addr: {addr}')
            if addr.get('ip') == ip and addr.get('port') == port:
                addrs.append(addr)
        return addrs
    
    def _update_total_devices_count(self):
        enabled_devices_count = sum(1 for row in self.device_rows if row.bot_config.is_enable)
        self.parent.update_total_devices_label(enabled_devices_count)


class DeviceRow(QWidget):
    def __init__(self, parent, device_list_table, main_frame, window_name, instance_name, exe_path, ip, port, model):
        super().__init__(parent)
        self.run_device_lock = threading.Lock()
        self.device_list_table = device_list_table  # Store reference to DeviceListTable
        self.main_frame = main_frame
        self.window_name = window_name
        self.instance_name = instance_name
        self.id = f"{ip}:{port}"
        self.exe_path = exe_path
        self.ip = ip
        self.port = port
        self.model = model
        self.device_frame = None
        self.device_frame_old = None
        self.bot = None
        self.bot_config = load_bot_config(f"{ip}_{port}")
        self.is_enable = self.bot_config.is_enable

        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(2)
        
        self.is_enable_check_bot = QCheckBox()
        self.is_enable_check_bot.setChecked(self.is_enable)
        self.is_enable_check_bot.stateChanged.connect(self.save_config)
        self.is_enable_check_bot.setStyleSheet("QCheckBox::indicator { width: 20px; height: 20px; }")

        self.icon = QLabel()
        self.set_icon()

        self.name_label = QLabel(self.window_name)
        self.name_label.setFixedWidth(100)  # Set fixed width for key entry
        self.name_label.setFixedHeight(30)
        self.status_label = QLabel(DISCONNECTED)
        self.status_label.setStyleSheet("color: red;")
        self.key_label = QLabel('Key: ')
        self.key_entry = QLineEdit(self.bot_config.vipKey)
        self.key_entry.editingFinished.connect(self.save_key)
        self.key_entry.setFixedWidth(200)  # Set fixed width for key entry
        self.key_entry.setFixedHeight(30)
        self.display_btn = QPushButton('Display')
        self.display_btn.setFixedHeight(30)
        self.del_btn = QPushButton('Delete')
        self.del_btn.setFixedHeight(30)
        self.start_btn = QPushButton('Start')
        self.start_btn.setFixedHeight(30)

        self.layout.addWidget(self.is_enable_check_bot)
        self.layout.addWidget(self.icon)
        self.layout.addWidget(self.name_label)
        self.layout.addWidget(self.key_label)
        self.layout.addWidget(self.key_entry)
        self.layout.addWidget(self.status_label)
        self.layout.addWidget(self.display_btn)
        self.layout.addWidget(self.start_btn)
        self.layout.addWidget(self.del_btn)
        self.log_frame = None

    def set_icon(self):
        if not self.exe_path:
            self.exe_path = ''
        if 'MEmu' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\MEmu.png')))
        elif 'LDPlayer' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\ldplayer.png')))
        elif 'NemuPlayer.exe' in self.exe_path or 'MuMuPlayer.exe' in self.exe_path:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\mumu.png')))
        else:
            self.icon.setPixmap(QPixmap(resource_path('resource\\icon\\bluestack.png')))

    def save_key(self):
        new_key = self.key_entry.text()
        self.bot_config.vipKey = new_key
        write_bot_config(self.bot_config, f"{self.ip}_{self.port}")

    def save_config(self):
        self.bot_config.is_enable = self.is_enable_check_bot.isChecked()
        write_bot_config(self.bot_config, f"{self.ip}_{self.port}")
        # Directly call the method on the stored DeviceListTable instance
        self.device_list_table._update_total_devices_count()

    def set_on_start_click(self, on_click):
        self.start_btn.clicked.connect(lambda: on_click(self))

    def set_on_del_click(self, on_click):
        self.del_btn.clicked.connect(lambda: on_click(self))

    def set_on_display_click(self, on_click):
        self.display_btn.clicked.connect(lambda: on_click(self))

    def add_log_frame(self):
        if not self.log_frame:
            self.log_frame = LogFrame()
            self.main_frame.addWidget(self.log_frame)
        self.main_frame.setCurrentWidget(self.log_frame)

    def show_disk_info(self):
        try:
            command = "wmic logicaldisk get Caption,Size,Freespace"
            process = subprocess.Popen(command, shell=True, stdout=PIPE, stderr=PIPE, text=True)
            stdout, stderr = process.communicate()

            if process.returncode == 0:
                disk_info_message = "Disk System Information:\n" + stdout
            else:
                disk_info_message = f"Error getting disk info:\n{stderr}"

            QMessageBox.information(self, "Disk Info", disk_info_message)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to get disk information: {e}")

