from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit
from PyQt5.QtCore import QTimer


class LogFrame(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.log_text = QTextEdit(self)
        self.log_text.setReadOnly(True)
        self.layout.addWidget(self.log_text)
        self.setLayout(self.layout)
        self.log_entries = []  # List to store log messages
        self.max_entries = 50  # Configurable max entries

    def append_log(self, message):
        """Append a log message and update the display."""
        # Add new message to the list
        self.log_entries.append(message)
        
        # Keep only the last max_entries
        if len(self.log_entries) > self.max_entries:
            self.log_entries.pop(0)  # Remove oldest entry
        
        # Append only the new message instead of rewriting all
        self.log_text.append(message)  # More efficient than clear() + setText()
        
        # Auto-scroll to the bottom asynchronously
        QTimer.singleShot(0, self.scroll_to_bottom)

    def scroll_to_bottom(self):
        """Scroll to the bottom of the log display."""
        scroll_bar = self.log_text.verticalScrollBar()
        scroll_bar.setValue(scroll_bar.maximum())

    def clear_logs(self):
        """Clear all log entries and the display."""
        self.log_entries.clear()
        self.log_text.clear()

    def set_max_entries(self, max_entries: int):
        """Set the maximum number of log entries to keep."""
        self.max_entries = max(1, max_entries)  # Ensure at least 1
        while len(self.log_entries) > self.max_entries:
            self.log_entries.pop(0)
            self.log_text.setText('\n'.join(self.log_entries))
            self.scroll_to_bottom()