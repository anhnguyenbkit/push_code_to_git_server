
import os
import sys
from PyQt5.QtWidgets import QMessageBox, QMainWindow, QTabWidget, QWidget, QVBoxLayout, QLabel, QProgressBar, QStackedWidget, QPushButton, QHBoxLayout, QApplication
from PyQt5.QtGui import QPixmap, QIcon
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QSize, QTimer
from gui.setting_frame import SettingFrame
from gui.bottom_frame import BottomFrame
from gui.device_list_frame import DeviceListFrame
from config import global_config
from utils import resource_path
from control_worker import start_worker, cleanup
from gui.communicator import Communicator
import time


class CustomTitleBar(QWidget):
    def __init__(self, version, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.version = version
        self.initUI()

    def initUI(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Add the icon to the title bar
        icon_label = QLabel(self)
        icon_pixmap = QPixmap(resource_path('resource/icon/favicon32.ico')).scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        icon_label.setPixmap(icon_pixmap)
        icon_label.setFixedSize(30, 30)  # Adjust the size as necessary
        layout.addWidget(icon_label)

        # Title label
        self.title_label = QLabel(f'RoK Bot Infinity({self.version})')
        self.title_label.setStyleSheet("color: white; font-weight: bold;")
        layout.addWidget(self.title_label)
        layout.addStretch()

        # Minimize button
        minimize_btn = QPushButton()
        minimize_btn.setIcon(QIcon(resource_path('assets/minimize.png')))  # Use the path to your minimize icon
        minimize_btn.setIconSize(QSize(24, 24))  # Adjust the size as necessary
        minimize_btn.setStyleSheet("background-color: transparent; border: none;")
        minimize_btn.clicked.connect(self.parent.showMinimized)
        layout.addWidget(minimize_btn)

        # Close button
        close_btn = QPushButton()
        close_btn.setIcon(QIcon(resource_path('assets/close.png')))  # Use the path to your close icon
        close_btn.setIconSize(QSize(24, 24))  # Adjust the size as necessary
        close_btn.setStyleSheet("background-color: transparent; border: none;")
        close_btn.clicked.connect(self.parent.close)
        layout.addWidget(close_btn)

        self.setLayout(layout)


class MainWindow(QMainWindow):
    local_version_file = resource_path('version/version.txt')  # Local version.txt file path
    message_box_signal = pyqtSignal(str, str)

    def __init__(self):
        super().__init__()
        os.environ['MAGICK_OCL_DEVICE'] = 'OFF'
        self.version = self.get_local_version()
        self.communicator = Communicator()
        self.summary_dialog = None
        self.refresher = None
        self.initUI()
        self.communicator.message_signal.connect(self.show_message)
        self.message_box_signal.connect(self.display_message_box)
        start_worker(self.communicator)

    def extract_version(self, version_string):
        if version_string.startswith("Version:"):
            return version_string.split("Version:")[1].strip()
        return None
    
    def get_local_version(self):
        
        # Read local version
        global_config.logger.debug(self.local_version_file)
        if os.path.exists(self.local_version_file):
            with open(self.local_version_file, 'r') as f:
                local_version = self.extract_version(f.read().strip())
        else:
            local_version = '1.7.0.0'  # If no local version, assume it's an old version

        return local_version

    def initUI(self):
        self.setWindowTitle(f'RoK Bot Infinity({self.version})')
        self.setGeometry(100, 100, 800, 800)
        self.setMinimumSize(800, 800)
        icon_path = resource_path("resource/icon/favicon32.ico")
        global_config.logger.debug(icon_path)
        self.setWindowIcon(QIcon(icon_path))

        # Set a custom title bar
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.title_bar = CustomTitleBar(self.version, self)
    
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)

        main_layout.addWidget(self.title_bar)

        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        main_frame = QWidget()
        main_frame_layout = QVBoxLayout(main_frame)

        self.log_stack = QStackedWidget()
        self.log_stack.setFixedHeight(120)

        self.dlf = DeviceListFrame(self.log_stack)
        dlf = self.dlf
        main_frame_layout.addWidget(dlf)
        
        sf = SettingFrame()
        self.setting_frame = sf
        main_frame_layout.addWidget(sf)

        self.tabs.addTab(dlf, 'DEVICES')
        # self.tabs.addTab(main_frame, 'Display Device')
        self.tabs.addTab(sf, 'SETTINGS')

        main_layout.addWidget(self.log_stack)

        bf = BottomFrame(main_frame)
        main_layout.addWidget(bf)

        self.setCentralWidget(main_widget)

    def show_message(self, title, message):
        self.message_box_signal.emit(title, message)

    def display_message_box(self, title, message):
        if self.summary_dialog and self.summary_dialog.isVisible():
            # Cancel existing auto-close timer if it exists
            if hasattr(self.summary_dialog, 'auto_close_timer') and self.summary_dialog.auto_close_timer:
                self.summary_dialog.auto_close_timer.stop()
            self.summary_dialog.close()

        self.summary_dialog = QMessageBox(self)
        self.summary_dialog.setIcon(QMessageBox.Information)
        self.summary_dialog.setText(message)
        self.summary_dialog.setWindowTitle(title)
        self.summary_dialog.setStandardButtons(QMessageBox.Ok)
        self.summary_dialog.setModal(False)  # Make the message box non-modal
        
        # Create timer with proper parent and safe callback
        timer = QTimer(self)
        timer.setSingleShot(True)
        timer.timeout.connect(self.close_summary_dialog)
        timer.start(60000)
        
        # Store timer reference on the dialog to prevent it from being garbage collected
        self.summary_dialog.auto_close_timer = timer
        
        self.summary_dialog.show()
    
    def close_summary_dialog(self):
        """Safely close the summary dialog if it exists and is visible."""
        if self.summary_dialog and self.summary_dialog.isVisible():
            self.summary_dialog.accept()

    # def set_menu_widget(self, widget):
    #     self.menuWidget().setVisible(False)  # Hide the default title bar
    #     self.setMenuWidget(widget)

    def run(self):
        self.show()

    def closeEvent(self, event):
        """Handle the window close event."""
        global_config.logger.info("Close button clicked. Shutting down.")
        self.dlf.save_device_config()
        cleanup()
        event.accept()
